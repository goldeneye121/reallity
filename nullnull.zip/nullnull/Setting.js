module.exports = {
    TokenS: "7961135875:AAHujaKyTfxfEGJtvzm-d1EN5b388OgBAu8",
    admins: ["7456641841"]
};