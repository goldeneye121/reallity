module.exports = {
  BOT_TOKEN: "7961135875:AAHujaKyTfxfEGJtvzm-d1EN5b388OgBAu8",
};